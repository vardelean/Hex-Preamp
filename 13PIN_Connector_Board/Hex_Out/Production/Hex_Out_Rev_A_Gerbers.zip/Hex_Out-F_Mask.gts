G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.0*
G04 #@! TF.CreationDate,2025-03-27T15:52:39-04:00*
G04 #@! TF.ProjectId,Hex_Out,4865785f-4f75-4742-9e6b-696361645f70,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.0) date 2025-03-27 15:52:39*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.102000X-0.754000X-0.754000X0.754000X-0.754000X0.754000X0.754000X-0.754000X0.754000X0*%
%ADD11C,1.712000*%
%ADD12C,2.304000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J4*
X153300000Y-84362500D03*
D11*
X150800000Y-84362500D03*
X148400000Y-84362500D03*
X146000000Y-84362500D03*
X154500000Y-86362500D03*
X152100000Y-86362500D03*
X149600000Y-86362500D03*
X147200000Y-86362500D03*
X153300000Y-88362500D03*
X150800000Y-88362500D03*
X148400000Y-88362500D03*
X146000000Y-88362500D03*
X149600000Y-90362500D03*
D12*
X145000000Y-100062500D03*
X155000000Y-100062500D03*
G04 #@! TD*
M02*
