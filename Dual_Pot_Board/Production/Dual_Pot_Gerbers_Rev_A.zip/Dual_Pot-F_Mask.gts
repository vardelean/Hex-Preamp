G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.0*
G04 #@! TF.CreationDate,2025-03-27T16:06:27-04:00*
G04 #@! TF.ProjectId,Dual_Pot,4475616c-5f50-46f7-942e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.0) date 2025-03-27 16:06:27*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10O,1.030000X1.730000*%
%ADD11RoundRect,0.250000X-0.265000X-0.615000X0.265000X-0.615000X0.265000X0.615000X-0.265000X0.615000X0*%
%ADD12C,2.004000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X79000000Y-64050000D03*
X77500000Y-64050000D03*
X76000000Y-64050000D03*
X74500000Y-64050000D03*
X73000000Y-64050000D03*
D11*
X71500000Y-64050000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,RV1*
X80000000Y-75000000D03*
X75000000Y-75000000D03*
X70000000Y-75000000D03*
X80000000Y-70000000D03*
X75000000Y-70000000D03*
X70000000Y-70000000D03*
G04 #@! TD*
M02*
